package com.study.rpc.config;

/**
 * 生产者配置
 */
public class ServiceConfig<T> {

    public Class<T> type;

    public T instance;

    public ServiceConfig(Class<T> type, T instance) {
        this.type = type;
        this.instance = instance;
    }

    public Class<T> getType() {
        return type;
    }

    public void setType(Class<T> type) {
        this.type = type;
    }

    public T getInstance() {
        return instance;
    }

    public void setInstance(T instance) {
        this.instance = instance;
    }
}
