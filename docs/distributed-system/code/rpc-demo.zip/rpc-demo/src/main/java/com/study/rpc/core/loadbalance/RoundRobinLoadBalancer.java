package com.study.rpc.core.loadbalance;

import com.study.rpc.core.registry.RegistryInfo;

import java.util.List;

/**
 * 轮训的负载均衡组件
 *
 */
public class RoundRobinLoadBalancer implements LoadBalancer {

    private RoundRobinLoadBalancer() {

    }

    @Override
    public RegistryInfo choose(List<RegistryInfo> registryInfos) {
        return null;
    }
}
