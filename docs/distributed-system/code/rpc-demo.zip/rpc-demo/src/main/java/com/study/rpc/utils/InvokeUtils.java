package com.study.rpc.utils;

import java.lang.reflect.Method;
import java.lang.reflect.Parameter;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * 反射工具类
 *
 * @author Jianfeng Wang
 * @since 2019/8/2 16:35
 */
public class InvokeUtils {


    /**
     * 返回clazz和方法的唯一标识
     */
    public static String buildInterfaceMethodIdentify(Class<?> clazz, Method method) {
        Map<String, String> map = new LinkedHashMap<>();
        map.put("interface", clazz.getName());
        map.put("method", method.getName());
        Parameter[] parameters = method.getParameters();
        if (parameters.length > 0) {
            StringBuilder param = new StringBuilder();
            for (int i = 0; i < parameters.length; i++) {
                Parameter p = parameters[i];
                param.append(p.getType().getName());
                if (i < parameters.length - 1) {
                    param.append(",");
                }
            }
            map.put("parameter", param.toString());
        }
        return StringUtils.map2String(map);
    }


}
