package com.study.rpc.core;

/**
 * 调用器
 *
 */
public interface Invoker<T> {


    /**
     * 调用过程
     */
    T invoke(Object[] args);

    /**
     * 设置响应结果
     *
     * @param result 响应结果
     */
    void setResult(String result);

}
