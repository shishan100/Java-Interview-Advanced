package com.study.rpc.core.loadbalance;

import com.study.rpc.core.registry.RegistryInfo;

import java.util.List;
import java.util.Random;

/**
 * 随机负载均衡
 *
 */
public class RandomLoadbalancer implements LoadBalancer {
    @Override
    public RegistryInfo choose(List<RegistryInfo> registryInfos) {
        Random random = new Random();
        int index = random.nextInt(registryInfos.size());
        return registryInfos.get(index);
    }
}
