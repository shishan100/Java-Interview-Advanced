package com.study.rpc.test.producer;

import com.study.rpc.config.ServiceConfig;
import com.study.rpc.core.ApplicationContext;

import java.util.ArrayList;
import java.util.List;

/**
 * 测试生产者
 */
public class TestProducer {


    public static void main(String[] args) throws Exception {
        String connectionString = "zookeeper://172.16.18.44:2181,172.16.16.132:2182,172.16.16.133:2181";
        HelloService service = new HelloServiceImpl();
        ServiceConfig<HelloService> config = new ServiceConfig<>(HelloService.class, service);
        List<ServiceConfig> serviceConfigList = new ArrayList<>();
        serviceConfigList.add(config);
        ApplicationContext ctx = new ApplicationContext(connectionString, serviceConfigList, null, 50071);
    }

}
