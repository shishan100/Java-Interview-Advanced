package com.study.rpc.test.producer;

/**
 * 测试服务类
 *
 */
public interface HelloService {

    String sayHello();

    String sayHello(String message);

    String sayHello(TestBean testBean);
}
