package com.study.rpc.core.registry;

import java.util.List;

/**
 * 广播方式注册中心,这里为了演示，不做具体实现
 *
 */
public class MulticastRegistry implements Registry {

    public MulticastRegistry(String connectString) {

    }

    @Override
    public void register(Class<?> clazz, RegistryInfo registryInfo) {

    }

    @Override
    public List<RegistryInfo> fetchRegistry(Class<?> clazz) {
        return null;
    }

}
