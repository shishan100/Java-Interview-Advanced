package com.study.rpc.test.producer;


/**
 * 测试实现类
 *
 */
public class HelloServiceImpl implements HelloService {

    @Override
    public String sayHello(String message) {
        return "牛逼，我收到了消息：" + message;
    }

    @Override
    public String sayHello(TestBean testBean) {
        return "牛逼,我收到了消息：" + testBean;
    }

    @Override
    public String sayHello() {
        return "牛逼啊，成功了";
    }
}
