package com.study.rpc.config;

/**
 * 消费者配置
 */
public class ReferenceConfig<T> {

    private Class<T> type;

    public ReferenceConfig(Class<T> type) {
        this.type = type;
    }

    public Class<T> getType() {
        return type;
    }

    public void setType(Class<T> type) {
        this.type = type;
    }
}
